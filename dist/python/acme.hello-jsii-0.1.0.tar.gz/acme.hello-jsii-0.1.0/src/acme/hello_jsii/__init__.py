"""
# Welcome to your CDK TypeScript Construct Library project!

You should explore the contents of this project. It demonstrates a CDK Construct Library that includes a construct (`Pipeline`)
which contains an Amazon SQS queue that is subscribed to an Amazon SNS topic.

The construct defines an interface (`PipelineProps`) to configure the visibility timeout of the queue.

## Useful commands

* `npm run build`   compile typescript to js
* `npm run watch`   watch for changes and compile
* `npm run test`    perform the jest unit tests
"""
import abc
import builtins
import datetime
import enum
import typing

import jsii
import jsii.compat
import publication

from ._jsii import *

import aws_cdk.core


class BuildSystem(
    aws_cdk.core.Construct, metaclass=jsii.JSIIMeta, jsii_type="pipeline.BuildSystem"
):
    def __init__(
        self, scope: aws_cdk.core.Construct, id: str, *, project_name: str
    ) -> None:
        """
        :param scope: -
        :param id: -
        :param project_name: The visibility timeout to be configured on the SQS Queue, in seconds. Default: Duration.seconds(300)
        """
        props = PipelineProps(project_name=project_name)

        jsii.create(BuildSystem, self, [scope, id, props])


@jsii.data_type(
    jsii_type="pipeline.PipelineProps",
    jsii_struct_bases=[],
    name_mapping={"project_name": "projectName"},
)
class PipelineProps:
    def __init__(self, *, project_name: str) -> None:
        """
        :param project_name: The visibility timeout to be configured on the SQS Queue, in seconds. Default: Duration.seconds(300)
        """
        self._values = {
            "project_name": project_name,
        }

    @builtins.property
    def project_name(self) -> str:
        """The visibility timeout to be configured on the SQS Queue, in seconds.

        default
        :default: Duration.seconds(300)
        """
        return self._values.get("project_name")

    def __eq__(self, rhs) -> bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs) -> bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PipelineProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "BuildSystem",
    "PipelineProps",
]

publication.publish()
